Hello,

Thank for downloading Broadway.

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:

- This font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase full version and commercial license: 
https://creatypestudio.co/broadway

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at
foundry@creatypestudio.co

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/CreatypeStudio
 
Please visit our store for more amazing fonts : 
https://creatypestudio.co

Follow our instagram for update : @creatypestudio

Thank you.

-------------------

INDONESIA:

Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

- Font demo ini hanya dapat digunakan untuk keperluan "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, Distro atau Perusahaan/Korporasi.

- Silakan gunakan lisensi komersial dengan membeli melalui link ini : 
https://creatypestudio.co/broadway

- Dengan hanya lisensi "Personal Use", DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, Desain kaos distro atau untuk Kemasan Produk (baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

- Untuk penggunaan keperluan Perusahaan/Korporasi silakan menggunakan Corporate License.

- Menggunakan font ini dengan lisensi "Personal Use" untuk kepentingan Komersial apapun bentuknya TANPA IZIN dari kami, akan dikenakan biaya CORPORATE LICENSE Versi Perkumpulan Desain Huruf Indonesia.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami di : foundry@creatypestudio.co

Terima kasih.